***********************************
*   The FACILITATOR for TSM       *
*             TFFT                *
* (C)2022 ZOCKINGER TECHNOLOGIES  *
***********************************
@FFT_Readme V1.18


What's new in this version (V1.18):   
  Preliminary ISP 8.1.13 Support
  Some small bugfixes
  License no longer required, TFFT expiration date removed.
  




   
  

Upgrade instructions:
** if you have made changes to your zocfft.ini you'll need to merge them with the new     **
** version of zocfft.ini to get the new alert definitions                                 ** 
** Take care not to overwrite your servers.ini file and to keep your DATA directory       **
Overwrite all other files with the new versions.




----------------------------------------------------------------------------------

TFFT - The Facilitator for TSM (IBM's Tivoli Storage Manager / Spectrum Protect)
A command line orientated user interface for the professional TSM administrator 

Features:

    * Real time TSM console
    * TSM macro & background Job control
    * Customizable alerts & message filters
    * Support for up to multiple TSM Servers (max 90 are supported at this time)
    * Centralized Master console
    * User defined functions 

System requirements:
    TFFT should run on all Windows Versions >= Windows 7
      with TSM Servers V5.5, V6, V7 and V8.1
      
    
          
  
  
Installation:
 - Unpack the contents of ZOCFFT.ZIP to a new directory.
 - Make a shortcut to ZOCFFT.exe in your Start Menu or Desktop
   If you need SSL connections to your TSM Server you'll need an installed ISP Administrative Client.
   This is due to the requirement to use SSL connections for admin sessions introduced in ISP 8.1.2
>>>  If you don't need ssl and/or you don't have any servers >=8.1.2 you can use the
     dsmadmc.exe that comes with TFFT (by specifying DSMADMCPATH = .\DSMADMC.EXE. )
	 This old dsmadmc version used far less memory and connects much quicker than recent versions.
	 However it can't do SSL so if you get the following error message:
	   "Session rejected: Downlevel client code version"
	 You'll have to update your admin id as follows:
        UPD ADMIN <YOUR_ADMIN_ID> SESSIONSEC=TRANS
		to keep using the old dsmadmc.exe. 
   In any other case you'll need to provide a working command line for TFFT to use. 
   So if an SSL connection is required, 
   please install a version 8.1.2 (or higher) ISP Client. Make sure you select "Custom Installation" 
   to install the "Administrative Command Line Files" 
   Set the DSMADMC parameter in zocfft.ini to fit your installation, the default is 
   "C:\Program Files\Tivoli\TSM\baclient\dsmadmc.exe"
        For Netconfig users: This parm can be overridden by placing the same entry in the [PREFS]
                             section of DATA\MEMORY.INI 
   
   To use SSL you must import your ISP Server Certificates, here is an example:
    
     cd /d "C:\Program Files\Tivoli\TSM\baclient"
     dsmcert -add -server <servername> -file <path_to_cert256.arm>

   Repeat this step for every ISP Server... Don't blame me - that's how IBM designed it...
      
   For more information have a look at the 
        IBM Spectrum Protect for Windows Backup-Archive Clients
        Installation and User's Guide
        Chapter "Configuring IBM Spectrum Protect client/server communication with Secure Sockets Layer" 
 
 
  To make the best use of TFFT's features you should enable server & node Messages
  for the console receiver of you TSM Servers (to display Storage Agent & Client Messages)
  Issue the following Commands on you TSM Servers to enable these Messages:
    enable events console info,error,warning,severe
    enable events console info,error,warning,severe node=*
    enable events console info,error,warning,severe server=*
  Attention: For TFFT to work correctly MessageID ANR2017 must be enabled for the Console
    receiver. This is the default setting, so if you have disabled it you'll need to
    re-enable it using "enable events console ANR2017"
  
 
   
Minimum configuration 
   * Start ZOCFFT    
   * select operating mode:
                   

     SINGLE SERVER opens 1 TFFT Window, use this if you have 1 TSM Server.   
                   Enter Userid, password, Server Address & Port   
     
                   
     MULTISERVER   opens a Master console and TFFT windows. Use this if you
                   have lots if TSM Servers to administer.
                   You will need to edit SERVERS.ini to add your TSM servers
                   At the moment up to 90 TSM Servers are supported.
                   You can also add Storage Agents here if they need monitoring
                   (e.g. during testing or for doing traces etc)
         AUTOSTART     If checked all Server connections specified in SERVERS.INI 
                       that have AUTOSTART = 1 will be started. 
                       Uncheck this if no server connections should be started now
                       (Same as command line Parm -NOAUTOSTART)
                       
                       If you disable MULTISERVER then you get one TFFT Window. 
                       Use this mode if you have 1 TSM 
                       Server or if you want to make ad hoc connections.
                       The last 10 IP Addresses will be remembered
                       
     QUICKSWITCH  TFFT displays a Systray icon and runs in the background.
                  Use this Mode if you have lots of Servers but don't
                  need to have them open at all times.
                  servers.ini is used to define TSM Serves (see MULTISERVER Mode)
                  You can but don't need to provide a password at startup.
                  When you Left Click the Facilitator Icon in the Systray
                  a Server Selection Screen is displayed. Click on a TSM
                  Server to start a connection.
                  Right Click the icon to get the familiar TFFT Popup Menu
                  (same as in Multiserver Mode)
                  When you start a another TFFT session the quickswitch
                  menu is displayed instead of a new TFFT window, this way
                  you can use a TFFT shortcut or taskbar pinned icon to
                  show the quickswitch window.
         RUN TFFT at Windows Startup
                     If you check this box TFFT will start automatically in
                     the background when you log on. 
           

To make the best use of TFFT's features you should enable server & node Messages
for the console receiver of you TSM Servers (to display Storage Agent & Client Messages)
Issue the following Commands on you TSM Servers to enable these Messages:
  enable events console info,error,warning,severe server=*
  enable events console info,error,warning,severe node=*

           
   
    Other Parameters:              
      Parameters in ZOCFFT.ini:
      EDITOR                -  specify your favourite editor, notepad.exe is the 
                                 default and this is NOT your favourite editor!
                    (why not give Notepad++ a try: http://notepad-plus-plus.org, 
                      it is freeware and very flexible)
                                This parm can be overridden by placing the same entry in the [PREFS]
                                section of DATA\MEMORY.INI (for use with netconfig)

        
                             
        WORKDIR               - Specify a working directory (default = %TEMP)
                                This is where temporary files are saved (EDIT,SAVE Buttons)
                                This parm can be overridden by placing the same entry in the [PREFS]
                                section of DATA\MEMORY.INI (for use with netconfig)
                
        MACDIR                - Specify a working directory (default = WORKDIR)
                                Default Folder for Macros
                                
        SESSIONTIMEOUT        - Specify a session timeout value (in seconds) to detect stale sessions 
                                (some firewalls or vpns just terminate sessions without tsm knowing about it)
                                If no data is received from a TSM Server within <SESSIONTIMEOUT> 
                                seconds a question mark is displayed in the Server Status Box 
                                (and a sound is played, if sounds are enabled). This setting can
                                be overridden with the IGNORESESSIONTIMEOUT parameter in servers.ini
                                
        V6BUTTONS2            - 0 No automatic Button set switching 
                                1 When connecting to a TSM V6 or V7 Server use Button Set 2 ([BUTTONS2] group
                                  in zocfft.ini)                    

        TSMSERVERS            - Number of TSM Servers for Multiserver & Quickswitch Mode
                                Possible Values: 30,40,50,60,70 80 or 90, 
                                other Values are ignored, default = 30
      
        CAMODE                - 0 Normal operation
                                1 Client Admin Mode. A special operation mode for Admins who mainly
                                administer TSM Clients. Only Single Server and Quickswitch Modes are
                                supported. CAMODE has its own sets of parameters in zocfft.ini:
                                [CASPAMFILTER],[CAALERTS],[CAFILTERS] and [CANOALERT]
                                In CAMODE Filters 1,2 and 4 are always active 
                                No Console Messages are apart from the ones specified in Filter3
                                (so its an include list really) or those found by the Bypass Filter
                                function. Message IDs specified in Filter 4 are never shown, regardless
                                of the Bypass Function. Commands issued by other Admins are never shown.
                                a sample configuration is included in zocfft.ini
                                
    QUICKSWITCHNOBG     -  This controls TFFT's startup behaviour in Quickswitch Mode
                            0 TFFT minimizes and shows an icon in the Systray
                            1 TFFT shows the Server selection Window at startup 
                                
    REMEMBERCOMMANDS       0 TFFT will not remember your command history
                           1 Command history is saved when you exit TFFT and available the next
                            time you use TFFT. All passwords are replaced by stars for security reasons.
                   
    SERVERSINSYSTRAY       0 Don't show TSM Servers in Systray Menu (Looks better lots of servers)
                           1 Show all TSM Servers in Systray Popup Menu (MultiServer Only)
                             This used to be the default up to V1.12 
  
  
        In the [UPGRADE] Section:
                This Section is only useful when used in combination with a central zocfft.ini
                configuration file on a web server using netconfig.ini
                You can specify the minimum recommended/required TFFT Software Level required 

        MINIMALVERSION  Specify the lowest Version allowed e.g. 1.04

        MANDATORY        Enforce the minimum Version = 1, or just nag = 0
    
        UPDATEINFO      String to display if you don't like the default Message 
                        Default = "Please install a newer Version of TFFT" or "You must install a newer Version of TFFT"
                        Use ~ to indicate a line break and $ to display the minimum Version
                              

         
    
                   
                   
      Parameters in SERVERS.INI:
        For each TSM Server (TSMSERVER01 - TSMSERVER30) you can specify:
          NAME               - a two letter nickname for the Server
          TCPS               - TCP/IP address or DNS name of the TSM Server
          TCPP               - TCP/IP Port number of the TSM Server
          ADMIN              - TSM Administrator ID
          COMMONPASSWORD     - 1 if you use the same password on all Servers
                               (passwords are NOT saved when TFFT quits)
                 Sorry still no support for different passwords for
                 Multiserver Mode yet
          AUTOSTART          - 1 Opens a session to this server when TFFT starts
          STARTHIDDEN        - This option keeps the Server's Window hidden
                               when using AUTOSTART
          SAVEMEMORY         - 0 Open all sessions to TSM Server when first
                                 connecting and don't close idle TFFT sessions
                                 (only useful when connecting to a TSM Server
                                  takes a long time)
                               1 Only open sessions when needed and close idle
                                 sessions after a while, keeps one session
                                 (this is the default)
                                 command open after connecting
                               2 Only open sessions when needed, close idle
                                 ones after a while and close the command
                                 session immediately after connecting
                                 (very useful if you have a lot of TSM Servers,
                                 each command session uses additional memory)
          BUTTONSET            1 Use Button Set 1 for this Server 
                                  (  Section [BUTTONS] in zocfft.ini )
                               2 Use Button Set 2 for this Server
                                  (  Section [BUTTONS2] in zocfft.ini )
          INFOTEXT             This text is displayed in Server Selection Menus
                               Format = Status\Info\Description (Use backslash '\' to separate Columns in Quickswitch Windows)
                               e.g. Active\DB\Server for Databases 
                               Will display Status=Active, Info=DB and Description='Server for Databases'
                               Use \\Bla if you only need a Description      
          IGNORESESSIONTIMEOUT 0 Default
                               1 Do not check for stale sessions          
  
                 
               
                

                               
                               
TFFT Commands:
?           Use the '?' command to get a Quick Overview of TFFT 
QUIT        Disconnect current session
QUITALL     Disconnect all sessions and stop TFFT                                  
EDINI       Edit ZOCFFT.ini
LOADINI     Reload settings from ZOCFFT.ini
EDSERVERS   Edit servers.ini (settings are only reloaded at TFFT startup)
TFFT or Z   Issue TFFT internal commands, see below  
   TFFT SAVE <filename>
      Saves the output of the last command to a file. If no filename is specified then
       FFT-<serverid>.TXT will be used.
       (Same function as the "SAVE" button)
      Shortcuts: "TFFT S", "Z S" or "ZS"
      
   TFFT EXEC 
      Execute the output of the last command as TSM statements
      Same function as the "EXEC" Button
      Shortcuts: "TFFT X", "Z X" or "ZX"
      
   TFFT MACC <filename>
      Execute TSM Macro from file with itemcommit, execution continues
      even when an error occurs. If no filename is specified then
      FFT-<serverid>.TXT will be used. That's the same filename 
      created by the TFFT SAVE command so the output from a TSM query
      can be run in the background as a TSM macro.
      Shortcuts: "TFFT M", "Z M" or "ZM"
       
   TFFT RUN
      Execute the output of the last command as a TSM Macro outside of TFFT
      Shortcuts: TFFT RUN or Z R or ZR
      Output is saved to a text file in the TFFT Work directory
      When TFFT exits all running macros are stopped, the last issued TSM
      command keeps on running of course.
   
   TFFT SUBMIT <KEEP>
      Defines a TSM script containing the last command's output and runs it
      Script Name = Z_TFFT_XX.YYYYMMDD_HHMMSS where XX is the TFFT TSM Server ID
      This script is deleted afterwards unless KEEP is specified
      Shortcuts: "TFFT SUB", "Z SUB" or "ZSUB"
      Output is saved to a text file in the TFFT Work directory
      When TFFT exits the TSM Script keeps running but output is no longer saved.
     
      
   TFFT FIND <string>
      Re-display lines from the last command output that contain the search string.
      FIND is case insensitive
      Shortcuts "TFFT F", "Z F" or "ZF"
      
   TFFT HIDE <string>
      Re-display lines from the last command output that don't contain the search string.
      HIDE is case insensitive
      Shortcuts "TFFT H","Z H" or "ZH"
      
      
   
   
      
     
      
   

all other commands will be routed to the TSM Server.
If a command takes too long to finish it will be executed in the background
so you can continue working.
A command can be prefixed with a control character to change the way the
command is executed:
&run bla   "&" will execute the command in the background, handy for long
            running scripts or when you need a notification when a command is
            finished, e.g. &def vol stgpool volname formatsize=128000 wait=yes
            
/run bla   "/" display the output in LIST mode. For some commands, e.g. some 
           tsm selects, the output is more usable using this format.
Output of a command can be redirected to a file by using '>' or '>>'
e.g. q act > d:\qact.txt or you can use the SAVE or EDIT Buttons to edit
or save the output of the last command.       
           



Filters:
There are 10 user definable filters for the TFFT Server Connections, the first
filter ('Commands') is fixed and filters out the Commands issued by the
TSM users specified in the '[EXCLUDEDUSERS]' section of ZOCFFT.ini.
The Second Filter ('Spam') is described below.
The Master console offers 4 user definable filters.

Spam filters:
You can define 80 Spam filters in the '[SPAMFILTER]' section of ZOCFFT.ini:
Specify one or more TSM Message IDs under SPAM1 and a spam string (STRING1)
for example SPAM1 = 1496 and STRING1 = What ho?,HELLO will filter out all ANR1496
Messages containing "What ho?" and "HELLO". The Spam filter is case sensitive.
Up to 50 Comma separated strings can be specified for each Spam filter.



Alerts:
There are 6 alert levels in TFFT, and some can be triggered  by user definable 
tsm messages.
Alerts are displayed in the output window as follows:
  FFT4000I Message XXXXXX trapped. Level 4 alert activated.
The alert will also show up on the Master console  
In addition to this the alert level is displayed in the left margin of the
output and master console window and the colour of the Systray icon changes. 
Furthermore the Server Status Indicator can change colour, blink and display
an icon depending on the alert level.  
You can switch of an alert by double clicking the server's status indicator.
In the default zocfft.ini, alerts are set so that you can try the alert
function: 
  ISSUE MESSAGE W "This is a warning"      will trigger a level 2 alert
  ISSUE MESSAGE E "This is an error"       will trigger a level 3 alert
  ISSUE MESSAGE S "This is a severe error" will trigger a level 5 alert
  

Operator Request - Fixed. SSI shows blinking question mark, Sound is played. 
Level 1 - Fixed. SSI blinks blue, Systray turns blue, Sound is played.
Level 2 - User definable. SSI blinks yellow, systray turns yellow.
Level 3 - User definable. SSI blinks red, systray turns yellow with red text.
Level 4 - User definable. SSI blinks red with attention sign, systray turns
          red. Sound is played.
Level 5 - User definable. SSI blinks white with attention sign, systray turns
          white. Sound is played.
          
You can also suppress an alert using the [NOALERT] section in ZOCFFT.ini
Specify ONE TSM Message IDs under NOALERT1 and a noalert string (STRING1)
for example NOALERT1 = 8302 and STRING1 = GETLOGSENSE will not trigger
an alert for getlogsense I/O errors
10 Comma separated strings can be specified for each string          
Furthermore you can prevent the messages caught here from showing up
on the Master Console by specifying a SKIPM Statement. For instance:
SKIPM1 = 1
SKIPM3 = 1
would not show the NOALERT1 and NOALERT3 Message on the Master Console  


Furthermore 8 User alerts can be defined using the [USERALERT] section of zocfft.ini
  Specify one or more TSM Message IDs under ALERT1 and one or more alert strings (STRING1)
  for example ALERT1 = 1496 and STRING1 = What ho?,HELLO will trigger a User alert
  for all ANR1496 Messages containing "What ho?" and "HELLO". The string is case sensitive.
  50 Comma separated strings can be specified for each User Alert.
  When a user alert is triggered the SSL will show a Bell symbol and a sound is played. 
  User alerts 1,2,3,4 and 5,6 and 7,8 play a different sound        
 

User definable buttons, default assignment:
BUCG        Show Backup Copy Groups
            Columns: PD    Policy Domain
                     MC    Management Class
                     DEST  Destination Storage Pool
                     VE    Versions Exists
                     VD    Versions Deleted
                     RE    Retain Extra
                     RO    Retain Only
                     FR    Backup frequency
                     D     Default Management Class (Y/N)
ARCG        Show Archive Copy Groups
            Columns: PD    Policy Domain
                     MC    Management Class
                     DEST  Destination Storage Pool
                     RETV  Retver
                     RETI  Retinit
                     RETM  Retmin
TAPEC       Count Tapes and show Utilization per storage pool                      
TAPES       Show Tape information
            Columns: VOL   Volume Label
                     STG   Storage Pool
                     STAT  Status
                     ACC   Access
                     UTIL  Utilization (in %)
                     RECL  Reclaimable space (in %)
                     RERR  Number of read errors
                     WERR  Number of write errors
ACT5M       Show Activity log from the last 5 minutes
DBLOG       Show DB & Log Info
CSESS       Show client sessions
            Columns: NODE_NAME  Node name
                     SESSION    Session number
                     recMB      MBs received from client
                     rMB/s      received data throughput
                     rVOL       sequential volume that receives the client data 
                                (blank if this is a diskpool, lanfree sessions
                                won't show up here, you'll need to query 
                                the storageagent directly (STAXXX: q se))
                     sentMB     MBs sent to the client
                     sMB/s      sent data throughput
                     sVOL       sequential volume used by the client 
                                see rVOL
                     MinW       Wait time in Minutes (Media wait etc.)
QSTG        Query Stgpool
QMO         Query Mount
QPRO        Query Processes
                      
FFT Fixed buttons:
MAC         Execute TSM Macro from file

MACC        Execute TSM Macro from file with itemcommit, execution continues
            even when an error occurs
            
EDIT        Edit the output of the last command

SAVE        Save the output of the last command to a file

EXEC        Execute the output of the last command as TSM statements
            For example: if you need to update all readonly volumes to
            readwrite. Issue the following command in FTT:
      select 'upd vol',volume_name,'acc=readw' from volumes where access='READONLY'
            the click the EXEC button to execute the generated commands
            The Column header is skipped automatically
            
            
DISC        Disconnect from TSM Server

CONN       (re)connect a connection to TSM Server

CLIENT MESSAGES Check box: When checked TFFT will also display all Client Messages (ANE)
           This will of course only work when Client Messages are enabled for the Console
       Receiver of the TSM Server. Issue the following command to enable Client Messages:
       enable events console info,error,warning,severe node=*
       


TFFT Keys:
Cursor Up/Down   Recall previous commands
Page Up          Scroll output 1 page up
Page Down        Scroll output 1 page down 1 
Ctrl+Cursor Up   Scroll output 1 line up
Ctrl+Cursor Down Scroll output 1 line down
Pause or Scroll lock - (un)pause scrolling 
Ctrl+Home        Jump to the top of the Output Area
Ctrl+End         Jump to the end of the Output Area
Esc              Cancel wait for a long running command


Copy/Paste:
Marked text in output is copied to the clipboard automatically
In addition to normal text selecting using click & drag, you can select one
or more lines by clicking in the left margin or you can select a rectangular
block of text with ALT+LEFTMOUSE.
Double clicking will select the word under the mouse pointer.

FFT has a putty-style paste function. Click the right mouse button in output 
area or command line as a paste shortcut.

Multiserver & Quickswitch mode:  
The Server Status Indicators (on the upper right) can be used to switch between
multiple TSM Servers (when multiserver mode is enabled)
Each define TSM Server has an entry here. You can right click an indicator to
make the Server's Windows 'sticky', i.e. it'll stay visible when you switch
to another Server.

The Multiserver Master console window displays the output of all TFFT connections.

Single, Multiserver & Quickswitch Mode:
Double click a server's status indicator, click on the CLEAR Button or issue 
the CLR or CLEAR command to turn off an alert.




NETCONFIG:           TFFT can be configured to use a central configuration stored
                     on a web server. 
                     Using NETCONFIG with quickswitch and windows autostart mode
                       you will always have a TFFT session ready with a centrally
                       administered and up to date config.
                     Configuration:
                     Place servers.ini and zocfft.ini files on a web server
                     (might need to rename them to *.txt on your web server)
                     Now make a netconfig2.ini (or .txt) with the following contents:
                       MULTISERVER = 2  
                       ZOCFFT  = http://yourserver.com/net_zocfft.ini
                       SERVERS = http://yourserver.com/net_servers.ini
                     Finally place a file names netconfig.ini in your TFFT directory
                     This file tells TFFT to get its config from URL specified. The
                     local zocfft.ini and server.ini will be ignored (and can even be deleted)
                     NETCONFIG.ini:
                       NETCONFIG = http://yourserver.com/netconfig2.ini
                     At startup TFFT will try to read the netconfig files, if this fails
                     cached copies of the files will be used, if there are any.  
                     A sample config file can be downloaded here:
                     http://files.zockinger.com/netconfig.ini
                     If you place this file in your tfft directory you can start 
                     TFFT with a sample configuration downloaded from the web.
   
                                          


Command line parameters:
  -NOAUTOSTART      In multiserver mode no Server connection will be
                    opened automatically (Same as un-checking the
                    AUTOSTART box in the startup dialog)
  -NOPOPUP          Normally if an instance of TFFT is running in quickswitch
                    Mode and you start another instance of TFFT the quickswitch
                    window pops up instead. For instance if you use the Windows 7
                    "Pin to Taskbar" feature. If you really want to start another 
                    TFFT instance you can make a shortcut to ZOCFFT.exe with
                    the -NOPOPUP option.                    
  
   
Version history:
V0.001  - V0.074    prog,crash,bla,aargh

V0.075 - 2007/05/09 First Alpha testing at selected sites
V0.095 - 2007/11/21 Alpha 2
V0.096 - 2007/12/03 Alpha 3
V0.097 - 2008/01/15 Alpha 4
V0.098 - 2008/02/13 Alpha 5
V0.099 - 2008/02/14 Alpha 6
V0.100 - 2008/02/26 Alpha 7
V0.101 - 2008/02/27 Alpha 8
V0.102 - 2008/03/03 Alpha 9
                     First public Alpha Version
                     New systray functionality
                     The 'reconnect into Oblivion' bug should be fixed.

V0.103 - 2008/04/08 Alpha 10
                    Various performance enhancements
                    Operator requests alert
                    
V0.104 - 2008/05/03 
                    First Beta Version + number of small bug fixes 

V0.105 - 2008/07/30 
                    A number of small bug fixes

V0.106 - 2008/10/06 
                    A number of small bug fixes

V0.108 - 2009/03/02 
                    A number of small bug fixes
                    new Alert triggers
                     
V0.20  - 2009/08/12 
                    User configurable Spamfilter
                    Alerts can be suppressed with the new Noalert function
                    1 Extra User definable Filter
                    Multiserver / Autostart can be selected in startup window
                    Logon history is kept
                    EXEC Button to execute command output
                    Lots of bug fixes and user requests implemented
                     
V0.21  - 2009/12/22   
                    A number of small bugs with message handling have been fixed
                    The beta period hes been extended to 2010, you will need this Version as V0.20 won't run in 2010. 
                    The START button is now called CONN (Connect) by user request.
                    Changed alerts (zocfft.ini v0080)
                     
V0.32  - 2010/04/20
                    4 extra user definable Buttons
                    changed/extra alerts (zocfft.ini v0087)       
                    Bugfix: Skips ANR2017 Admin xxx issued should now also work for messages from Storage agents
                    Bugfix: Left sidebar alert markers now also show up in master console
                    Bugfix: No more hanging Server Status Lights 
                    Multiserver: more servers started in parallel to speed up the TFFT's start process
                    Alerts show up in reverse colours to increase visibility

V0.33  - 2010/07/18
                    NOALERT Error Messages can optionally be suppressed on Master-console with SKIPMx statements
                    Typing in command gadget now prevents session memory save
                    Closing a Window now only closes the current Server (Multiserver mode)
                      Closing the Master console still closes the whole application
                    Bugfix: TFFT was unusable on machines with uptime > 3 weeks
                    Bugfix: TFFT could crash when alt-selecting a output
                    Bugfix: When a Help command goes into background, the first output line was cut
                    Bugfix: PwdBox Userid Gadget is now Uppercase, should fix ZB000201
                    Bugfix: In single server mode alert numbers didn't show up in the left sidebar
          
V0.99  - 2010/12/08
                    No scroll delay for Commands that start a process
                    Commands that need reformatting (e.g. select statements that exceed the current windows' width)
                      are remembered so in future no reformatting is needed. Message FFT0025W is displayed if 
                      such a command is learned.       
                    Bugfix: In rare cases TFFT would crash under Windows7
                    Bugfix: After reconnecting to a TSM Server the alert sidebar info was not displayed in the correct line

V0.99a - 2010/12/19
                    Emergency bugfix due to "Invalid memory access" issues

V0.99b - 2011/01/03
                    Another Emergency bugfix due to "Invalid memory access" issues

V0.99c - 2011/06/27
    ZB0004 Bugfix: When first command issued produced a Proceed? (Y/N) the command could hang
    ZB0005 Bugfix: Timer bug with Autoreply
    ZB0022 Bugfix: CMD remains in BG forever
    ZB0025 Bugfix: Editgadet gets focus all the time
    ZB0005 Bugfix: More Timer issues
    ZB0030 Bugfix: Avoid partial lines after window resize
    ZB0001 Bugfix: Command line should activate after (Y/N) question
    ZB0031 Experimental: New Quickswitch Mode can be selected in the startup dialog. 
      In quickswitch mode TFFT displays only a system tray icon. 
      Useful if you have a number of TSM Servers but you don't need to to have them all 
      connected at the same time and don't need the Master Console. 
      Click on the icon and a TSM Server Selection Window is displayed. 
      Here you can select one of your TSM Servers. (Right click on the icon and you get the usual TFFT Popup Menu)  

V0.99d - 2011/08/01 
    Release Candidate
    
V1.00 -  2011/12/12 - First release 
    TSM V6 Support through a second set of User definable Buttons
    TSM V6 Sql compatible Default Buttons
    Support for up to 90 TSM Servers
    Bypass Filter Text box
    "Run at Windows Startup" option for Windows Quickswitch Mode  
    Quickswitch Mode only asks for TSM password when a connection is made
    New Filers & Alerts
    BUTTONSET and INFOTEXT options in servers.ini
    SESSIONTIMEOUT option in zocfft.ini
    V6BUTTONS2 option in zocfft.ini (automatically select Button Set 2
      when connection to a TSM V6 Server).
    Command queue counter can now display 3 digits
    Queued commands now get formatted correctly
    ZB0006 rfc: Dateformat 4 (DD.MM.YYYY) is used by Default.
      edit dsm.opt in in your tfft directory to change this.
    ZB0026 Bugfix: Pink SSI block for large amounts of output does Not disappear.
    ZB0037 Bugfix: Connect hangs in C Status
    IGNORESESSIONTIMEOUT parameter in zocfft.ini
    Mount request alerts automatically switch off after Message timeout
    -NOPOPUP command line option
    Client Admin Mode 
    Netconfig, Central configuration on web server

V1.03a - 2012/09/12 
    More than 50 bug fixes, a LOT of work has gone into this, pfeew!
    Ctrl-Tab Switches to next active Server (Multiserver & Quickswitch Mode) 
    Shift-Ctrl-Tab Switches to previous active Server (Multiserver & Quickswitch Mode) 
    Tab-Switch to other server using Tab-XX, XX = 2 Character Server ID (Multiserver & Quickswitch Mode) 
    Clear Button to Clear Alerts on Server Windows & Master Console
    CLEAR, CLR command to Clear Alerts 
    Button to Enable/Disable Sounds on Server Windows & Master Console
      (Removed SOUND Parm in ZOCFFT.ini)
    Improved (MASTER) Filters for TSM V6 
    Improved Default V6 Button definitions
    Fixed TSM V6 CSESS Button, it produced false throughput values
    MACDIR Parameter in ZOCFFT.ini
    Command history now hides passwords in recalled commands 
      (this is in preparation for remembering the command history in the next release)
    
V1.03b - 2013/01/01
    Emergency Fix, TFFT wouldn't start after 2012/12/31

V1.04 - 2013/08/21
    ZB0056 TFFT remembers Command history    
    ZB0065 Background Jobs get a JOB-ID number
    ZB0083 In Quickswitch Mode the selection Window can be displayed at startup
           instead of TFFT going to Systray
    New "Client Messages" Button to enable/disable Client (ANE) Messages
       enable events console info,error,warning,severe node=*
       must be issued on the TSM Server for this to work         
    Better TSM V6 ANR9999D handling
    Improved default Buttons for TSM V6
    Support for TSM6.3.4
    Spam filter now supports up to 50 search strings per Filter
    8 User alerts can now be defined (with 50 search strings each) 
    In several Messages where the number of bytes processed is shown TFFT will
      calculate and show a "human readable value" in brackets (KB/MB/GB/TB...)
    Removed reverse colouring for Error Messages
    Window Flash for alerts can now be disabled  specify FLASH = 0 in 
      Data\Memory.ini in the [PREFS] section

V1.04a - 2013/09/12
    Bugfix: In Client Admin mode the new "Client Messages" Check box had no function, fixed
    
V1.10 - 2014/02/28
    Numerous bug fixes
    Support for TSM Version 7.1 
    V6BUTTONS2 now also works for V7 Servers
    Added Filter for Config Manager Messages
    Added Filter for TSM V7 Monitor Messages
    Improved Filters & Default Buttons
    Upgrade Section in zocfft.ini to force minimum TFFT Version 
    Window Flash for alerts are now disabled by default (can be enabled by specify 
    FLASH = 0 in Data\Memory.ini in the [PREFS] section

V1.11 - 2015/02/23
    Connection to servers with Invalid Date is now possible (e.g to issue "ACCEPT DATE") 
    Autostart will abort when user's password is invalid
    TFFT Commands to perform the same functions as the EXEC, MACC and SAVE buttons are now available 
    Duplicate line deduplication in output window ("previous Message was issued x times")  
    ZB0128 Bugfix: Quickswitch Window should stay on top of other windows.
    
V1.12 - 2015/03/09
    ZB0129 Bugfix: Temporarily deactivated the faulty Message Dedup Function

V1.12b - 2016/12/21
    Some small bug fixes. Trial period extended.
    
V1.13beta05 - 2016/07/20    
    This version contains a large number of changes and some of the core functions have
    been completely rewritten. Therefore its released as a Beta version at first
    so you can help me squash some of the new bugs that might have crept in.
    -- 
    TFFT now allows you to change your password when expired
    Better support for TSM7.1.4 and up
    New Filters for TSM V7
    Windows can now be maximized.
    Improved Gui responsiveness 
    Lower CPU utilization in favour of higher memory utilization
    The wait for a long running command can be interrupted by pressing the Escape key
    EDITOR and WORKDIR Parms from netconfig zocfft.ini can be overridden by user
    2 new ways to run command output:
      TFFT RUN    : runs output of previous command as a Macro in background
      TFFT SUBMIT : runs output of previous command as a TSM Script
    New TFFT FIND and TFFT HIDE Command to include/exclude output lines
    Support for the horrible 32k character long fields introduced in TSM V71x (why IBM, why???)
    Lots of Bug fixes, rewritten parts of core functions

V1.13.beta06 - 2016/07/21
  some bugs fixed  
    
V1.13.beta07 - 2016/10/10
  various bug fixes
  Added SERVERSINSYSTRAY option, 1 = Show all Servers in Systray Menu (as in pre V1.13)
  Known errors: TFFT RUN will sometime issue garbage commands.   

    
V1.13.rc1 - 2016/12/06 Release Candidate
  fixed 2 small bugs
  80 Spam filters can be defined (was 8)
  Output file names (TFFT SAVE, RUN, SUBMIT) can be opened in editor by clicking
    on the the file name.

V1.13.rc2 - 2016/12/13 Release Candidate
  Connecting to multiple TSM Server should be quicker
  Trying to avoid false positives with some Anti-virus programs
  
V1.13.rc3 - 2017/01/24 Release Candidate
  fixed 2 tiny bugs

V1.13.rc4 - 2017/01/27 Release Candidate
  Preliminary TSM/ISP V8.1.0 Support

V1.13 - 2017/03/15 Release
  ZB0414 - ANS1398E Write Error at startup
  ZB0415 - Maximized windows shrink when a command asks for confirmation
  Allow more characters in password for LDAP
  TFFT SUBMIT: Skip Lines ending in "-" 
  TFFT SUBMIT: KEEP Option added

V1.13a - 2017/04/17 
  fixed 2 small bugs
  Changed some compiler options to avoid false positives with some Anti virus programs
   
V1.14  - 2017/08/21
  fix for systems that don't have the VC++ 2008 Redistributable x86 installed 
  fixed 3 small bugs
  
V1.15  - 2017/11/06
  Preliminary support for ISP 8.1.2 
  Attention: TFFT now requires an installed ISP Administrative Command Line, 
  the requirement for an SSL encrypted connection for ISP 8.1.2 and up made this change necessary  
  Then new DSMADMCPATH parameter in zocfft.ini must point to your dsmadmc.exe
  (Default is "C:\Program Files\Tivoli\TSM\Baclient\dsmadmc.exe")
  DSMADMCPATH Parm from netconfig zocfft.ini can be overridden by user
  To use SSL you must import your ISP Server Certificates
  See Installation section in this readme file

V1.16  - 2018/07/10
  Lots of Bug fixes   
  Improved ISP 8.x support 

  
    
V1.17  - 2020/04/29
  ISP 8.1.9 support
  Important Bugfix: Background Jobs never returned in V1.16
  Lots of little bug fixes and improvements
  Old dsmadmc is included again for non SSL connections and portable installations
  Fall back to "Consolas" Font on systems where Custom Font Loading is prohibited by Group Policy (grrr)
  Much longer Scroll Delay for ISP Help Commands
  Calculate KB/MB/GB/PB values for more Messages (ANR0951I and ANR3692W)
  Added SAVEMEMSS parm in ZOCFFT.ini
  4 additional Master Filters
  1 additional User filter
  Add "EVENTS" Button in Prefs Tab - This issues all ENABLE EVENTS commands needed for optimal operation of TFFT
  
  
V1.18  - 2022/01/10
  Preliminary ISP 8.1.13 Support
  Some small bugfixes
  License no longer required, TFFT expiration date removed.
  
                    
                    
                    
   
  
  
 

======================================================================= 
 And now for something completely different:

TFFT is offered as Donationware. 
Please support development by making a donation 
  using paypal to zockinger@zockinger.com
  or by any of the following cryptos
  Bitcoin:     1JxyF7EhXyJSxZMPmk8VkmrSgD8DaQjm34
  BitcoinCash: qr2e6cxev4y0yw5amwam3vtrzxaqfn3j4sn8p58afn
  Ethereum:    0x1cf1373B784AEEAFd004C6cAdD7D1638aDcA6Fb1
  LiteCoin:    LNEaB8bYwewqMXXP399d26KjXKsBLoNkes  


Copyright � 2009-2012 by Zockinger Technologies. All rights reserved.

Redistribution and use in binary form, without modification, 
is permitted provided that the following condition is met:

-  Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
        

======================================================================= 
TFFT uses the superb scintilla edit component so...

License for Scintilla and SciTE

Copyright 1998-2002 by Neil Hodgson <neilh@scintilla.org>

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

NEIL HODGSON DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS 
SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS, IN NO EVENT SHALL NEIL HODGSON BE LIABLE FOR ANY 
SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES 
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, 
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER 
TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE 
OR PERFORMANCE OF THIS SOFTWARE. 

=======================================================================
TFFT uses the superb Dina Font so...

License for Dina Font:

The Dina font is free. You are welcome to use, distribute and modify 
it however you want, just don't use it for anything illegal or 
claim that you made it.
The Dina font is provided 'as-is', without any express or 
implied warranty. In no event will the authors be held liable
for any damages arising from the use of this font.
Copyright � 2005 by J�rgen Ibsen, All Rights Reserved.

=======================================================================

The following terms are trademarks of the 
International Business Machines Corporation in the United States,
other countries, or both:
IBM
Tivoli
Spectrum Protect

=======================================================================

 